--Name : SUNDEEP A
--SRN  : PES1UG20CS445
--Roll No : 48


--Question 1 : Find the list of passengers (user_id, user_type First name and last name) 
             --who have traveled from Bengaluru to Chennai during the month of Oct 2021 and Aug 2022
select user_id,user_type,firstname,lastname from ticket
join train_user on passenger_id=user_id
where departure='Bengaluru' and arrival='Chennai' and travel_date 
between '2021-10-01' and '2021-10-31' 
union
select user_id,user_type,firstname,lastname from ticket
join train_user on passenger_id=user_id
where departure='Bengaluru' and arrival='Chennai' and travel_date 
between '2022-08-01' and '2022-08-31';

--Question 2 : Find the list of passengers (user_id, user_type First name and last name) 
             --who have traveled from Bengaluru to Chennai during the month of Oct 2021 and also during Aug 2022
select user_id,user_type,firstname,lastname from ticket
join train_user on passenger_id=user_id
where departure='Bengaluru' and arrival='Chennai' and travel_date 
between '2021-10-01' and '2021-10-31' 
intersect 
select user_id,user_type,firstname,lastname from ticket
join train_user on passenger_id=user_id
where departure='Bengaluru' and arrival='Chennai' and travel_date 
between '2022-08-01' and '2022-08-31' ;

--Question 3 : Find the list of passengers (user_id, user_type First name and last name) 
             --who have traveled from Bengaluru to Chennai during the month of Aug 2022 and not in Oct 2021
select user_id,user_type,firstname,lastname 
from train_user,ticket where user_id = passenger_id and
departure='Bengaluru' and arrival='Chennai' and
not(travel_date<'2021-11-1' and travel_date>'2021-09-30') 
union 
select user_id,user_type,firstname,lastname from train_user,ticket 
where user_id = passenger_id and departure='Bengaluru' and
arrival='Chennai' and (travel_date>'2022-07-31' and
travel_date<'2022-09-01');



--Question 4 : Find the list of passengers (user_id, user_type, First name and last name) 
             --who have traveled from Bengaluru to Chennai and returned to Bengaluru within a week.
select user_id,user_type,firstname,lastname from ticket as
ticket1 join train_user on passenger_id=user_id
where departure='Bengaluru' and arrival='Chennai' and
exists(
select user_id,user_type,firstname,lastname from
ticket as ticket2 join train_user on passenger_id=user_id 
where departure='Chennai' and arrival='Bengaluru' and
(DATEDIFF(ticket2.travel_date,ticket1.travel_date) BETWEEN 0 and 7));



--Question 5 : Find the list of passengers (user_id, user_type, First name and last name) 
             --who have traveled from Bengaluru to Chennai and did not return to Bengaluru 
             --(in other words, only one way travel from Bengaluru to Chennai)
select user_id, user_type,firstname,lastname 
from ticket as t,train_user where passenger_id = user_id and 
Departure ='Bengaluru' and Arrival = 'Chennai' and 
not exists(
select pnr from ticket as ti where t.passenger_id = ti.passenger_id 
and Departure = 'Chennai' and Arrival = 'Bengaluru');