--Name : SUNDEEP A
--SRN : PES1UG20CS445
--Roll No : 48

--Assignment1:

DELIMITER $$
CREATE TRIGGER checking_compartment_no BEFORE INSERT on compartment for each row
BEGIN
IF (SELECT count(compartment_no) FROM compartment WHERE train_number=NEW.train_number)>=4 THEN 
SIGNAL SQLSTATE '45000' SET message_text="Sorry, Cannot add more than 4 Compartments to a Train ";
END IF;
END $$
DELIMITER ;

--Inserting values :
insert into compartment values("F02","III Class",20,5,25260);

insert into compartment values("F01","I Class",20,5,25261);

--Assignment 2:

--Trigger
DELIMITER $$
CREATE TRIGGER backup_trigger BEFORE DELETE ON ticket FOR EACH ROW
BEGIN
INSERT INTO backup SELECT * FROM payment_info WHERE
payment_info.pnr = OLD.pnr;
END $$
DELIMITER ;

--When trying to delete : 
delete from ticket where pnr = "PNR003";

select * from backup;
