--Name : SUNDEEP A
-- SRN : PES1UG20CS445
-- Roll No : 48
-- Subject : DBMS


--Q1 : Update the price of the ticket
    -- a.  Create a view view1 as shown below
create view view1 as SELECT Ticket.PNR, Ticket.Train_No, Ticket.Departure, Ticket.Arrival,Route_Info.Distance, Fare.fare_per_km 
FROM Ticket, Route_Info, Fare WHERE (Ticket.Train_No = Route_Info.Train_No AND Ticket.Departure = Route_Info.From_Station_Name AND Ticket.Arrival = Route_Info.To_Station_Name AND 
Fare.Train_Type=Ticket.Train_Type AND Fare.Compartment_Type =Ticket.Compartment_type);

    -- b. Create a view view2 as shown below:
CREATE VIEW view2 AS select PNR, count(PNR) as Numbers from Ticket_Passenger group by PNR;
    -- c. Updating the Price of Ticket : 
UPDATE Payment_Info AS p INNER JOIN view1 AS v1 ON p.PNR = v1.PNR INNER JOIN
view2 AS v2 on v1.PNR= v2.PNR SET p.Price = v1.Distance*v1.Fare_Per_KM*v2.numbers;


--Q2  : Retrieve the all stations along route of the Trains along with the distance between the stations
select train_no,from_station_name,to_station_name,distance from route_info 
where to_station_no-from_station_no=1 order by train_no;
--Q3  : Retrieve the Train no of train which is leaving Bengaluru and arriving at Chennai With compartments availability greater than 10
select route_info.train_no from route_info inner join compartment on
route_info.train_no = compartment.train_number where compartment.availability > 10 and 
from_station_name = "bengaluru" and to_station_name = "chennai";

--Q4  : Retrieve first and last name of users who have booked a ticket with price greater than 500
select distinct name from ticket_passenger inner join payment_info on ticket_passenger.pnr = payment_info.pnr where price > 500;
--Q5  : Retrieve the first name, last name, DOB and ticket PNR if they’ve bought it for all users.
select firstname, lastname, dob, pnr from train_user left join ticket on user_id = passenger_id where ticket.pnr is not null;
--Q6  : Retrieve the first name, last name of the Users who have not bought a ticket.
select firstname, lastname from train_user left join ticket 
on user_id = passenger_id where user_id not in (select passenger_id from ticket);
--Q7  : Retrieve the ticket PNR, Train number, travel date and along with all users first name and last name.
SELECT pnr,Train_No,Travel_date,firstname,lastname
FROM train_user RIGHT OUTER JOIN ticket ON 
train_user.user_id=ticket.passenger_id WHERE train_user.user_id is not null;
--Q8  : Retrieve the user id if they’ve traveled in a train along with train id and name of all trains.
select passenger_id,ticket.train_no,train_name from ticket RIGHT OUTER JOIN train 
on ticket.train_no=train.train_no where (CURRENT_DATE > ticket.Travel_date);
--Q9  : Retrieve the train no and name of trains whose destination is not Mangaluru 
      --and distance is not less than 100km and departure time is not 8:30:00 PM.
SELECT t1.train_no,t1.train_name from train as t1, (select distinct t2.train_no from route_info as 
t2,(select distinct train_no from ticket where departure_time!="20:30:00") as t3 where 
(t2.train_no=t3.train_no) and (t2.Distance>100)) as t2 where (t1.train_no=t2.train_no) and 
(t1.Destination!="Mangaluru");

--Q10 : Retrieve the User ID who has spent more ticket price than the average ticket price.
select distinct passenger_id from ticket join payment_info on 
ticket.pnr=payment_info.pnr where payment_info.price>(select avg(price) from 
payment_info);





