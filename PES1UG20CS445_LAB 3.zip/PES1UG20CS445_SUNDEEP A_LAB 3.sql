"
Name : Sundeep A
Roll No : 48
SRN : PES1UG20CS445
"


"Creating a new Database:"
create database SUNDEEP_PES1UG20CS445_Railway_Reservation;
use SUNDEEP_PES1UG20CS445_Railway_Reservation;

"Create Table Train:"
create table Train(Train_no int primary key not null,Name varchar(30) not null,Arrival varchar(30),
Destination varchar(30),Availability boolean,Train_type varchar(30) not null);
desc Train;

"Create Table Compartment:"
create table Compartment(Type varchar(30) not null,Compartment_no int,Capacity int,Availability boolean,
Train_no int,Foreign key(Train_no) references Train(Train_no),primary key(Train_no,Compartment_no));
desc Compartment;

"Create Table Route Info:"
create table Route_Info(From_Station_no int,From_Station_Name varchar(30),To_Station_Name varchar(30),
Distance float,Train_no int,Foreign key(Train_no) references Train(Train_no),primary key(From_Station_no,Train_no,Train_no));
desc Route_Info;

"Create Table User:"
create table User(User_Id varchar(30) primary key,User_Type varchar(30),Fname varchar(30),Lname varchar(30),
Age int,DOB date,Pincode int,Street_No int);
desc User;

"Create Table User_Train:"
create table User_Train(Train_no int,User_Id varchar(30),Date_Time_Stamp timestamp,Foreign key(Train_no) references Train(Train_no),
Foreign key(User_Id) references User(User_Id),primary key(Train_no,User_Id,Date_Time_Stamp));
desc User_Train;

"Create Table User_Phone:"
create table User_Phone(User_Id varchar(30),Phone_no int,Foreign key(User_Id) references User(User_Id),
primary key(User_Id,Phone_no));
desc User_Phone;

"Create Table Ticket:"
create table Ticket(PNR int primary key,Train_no int,Travel_Data date,Departure varhcar(30),Arrival varchar(30),
Departure_time time,Arrival_time time,User_Id varchar(30),Train_Type varchar(30),Compartment_Type varchar(30),Compartment_no int,
Foreign key(User_Id) references User(User_Id));
desc Ticket;

"Create Table Ticket_Passenger:"
create table Ticket_Passenger(Seat_no int,Name varchar(30),Age int,PNR int,Foreign key(PNR) references Ticket(PNR),
primary key(Seat_no,PNR));
desc Ticket_Passenger;

"Create Table Payment_Info":
create table Payment_Info(Transaction_Id int,Bank varchar(100),Card_Number bigint,Price float,
PNR int,primary key(Transaction_Id,PNR),Foreign key(PNR) references Ticket(PNR));
desc Payment_Info;

"Create Table Fare_Info:"
create table Fare_Info(Train_Type varchar(30),Compartment_Type varchar(30),
Fare_Per_KM float,primary key(Train_Type,Compartment_Type));
desc Fare_Info;

"Tasks:"
"3..  Alter Default of Availability attribute to Yes"
alter table Compartment alter Availability set default true;
desc Compartment;

"Train Name should be made Unique:"
alter table Train add unique(Name);
desc Train;

"Add Check Constraints to User to Check if the passenger age is above 5:"
alter table User add check(age>5);

"Rename:"
rename table Fare_Info to Fare_Table;
show tables;

"Insert Values into Fare Table: "
insert into Fare_Table Values
("Express","SL",5),
("Express","3A",12),
("Passenger","2S",3),
("Express","HA1",20);

select * form Fare_Table;

"Using Truncate Commands:"
truncate Fare_Table;
select * from Fare_Table;

"Using Drop Commands:"
drop table Fare_Table;