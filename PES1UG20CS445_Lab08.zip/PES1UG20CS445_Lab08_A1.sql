--Name : SUNDEEP A 
--SRN : PES1UG20CS445
--Roll No : 48



--Assignment 1
--Function
DELIMITER $$
CREATE FUNCTION count_tic(tic int)
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
DECLARE val varchar(50);
IF tic>3 then
set val="Cannot purchase tickets Current limit is over";
ELSE 
set val = "You can buy more Tickets";
end if;
return val;
END $$

--Function Call
with i as (Select passenger_id,count(pnr) as cnt from ticket group by passenger_id )
select passenger_id,count_tic(cnt) as Validate,cnt as ticket_purchased from i;



