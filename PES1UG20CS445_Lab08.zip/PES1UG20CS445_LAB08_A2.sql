--Name : SUNDEEP A
--SRN  : PES1UG20CS445
--Roll No : 48 

--Assignment 2 : 

--Procedure
DELIMITER $$
CREATE procedure age_update(IN UID varchar(30),IN DOB date, OUT message varchar(30))
BEGIN
DECLARE age int;
IF DOB>sysdate() THEN
set message= 'Invalid DoB';
ELSE
update train_user
set Age=(datediff(sysdate(),DOB))/365
where User_id= UID;
update train_user
set DoB=DOB
where User_id=UID;
set message='Age updated Successfully';
END IF;
END;

--Updating the Age :
CALL age_update('USR_001','2002-07-28',@Age);
SELECT @Age;